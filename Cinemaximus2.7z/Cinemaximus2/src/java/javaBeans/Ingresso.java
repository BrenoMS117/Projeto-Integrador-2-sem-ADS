package javaBeans;
import java.sql.DriverManager; // Driver para abrir Conexão 
import java.sql.ResultSet;
import java.sql.SQLException;  // Tratamento de Erros SQL
import java.sql.Connection;    // Armazena a Conexão Aberta
import java.sql.PreparedStatement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javaBeans.Conectar;


public class Ingresso extends Conectar {
    public int id_filme;
    public String pkuser;
    public String filme;
    public String horario;
    public String tipo;
    public String data;

   
    

    public boolean getFilme() {
        this.statusSQL = null;
        
        try {
            sql = "select * from ingresso where pkuser = pkuser ";
            ps = con.prepareStatement(sql); // prepara SQL
            
            tab = ps.executeQuery(); // Executa comando SQL
            if (tab.next()) {
                pkuser = tab.getString("pkuser");
                filme = tab.getString("filme");
                data = tab.getString("data");
                horario = tab.getString("horario");
                tipo = tab.getString("tipo");
                return true;
            }
            
        } catch (SQLException ex) {
            this.statusSQL = "Erro ao tentar buscar Usuário! " + ex.getMessage();
        }
       
        return true;
    }

    public void incluir() {
        try {     
            sql = "insert into ingressos (pkuser, filme, data, horario, tipo) "
                    + "values (?,?,?,?,?) ";

            ps = con.prepareStatement(sql); // prepara SQL
            ps.setString(1, pkuser); // Configura Parametros
            ps.setString(2, filme); // Configura Parametros
            ps.setString(3, data); // Configura Parametros
            ps.setString(4, horario); // Configura Parametros
            ps.setString(5, tipo); // Configura Parametros

            ps.executeUpdate(); // executa comando SQL
            this.statusSQL = null; // armazena null se deu tudo certo
        } catch (SQLException ex) {
            this.statusSQL = "Erro ao incluir usuario ! <br> " + ex.getMessage();
        }
    }
}

